package gnu.crypto.pad;

// ----------------------------------------------------------------------------
// $Id: PKCS1_V1_5.java,v 1.1 2003/10/28 19:09:48 raif Exp $
//
// Copyright (C) 2003 Free Software Foundation, Inc.
//
// This file is part of GNU Crypto.
//
// GNU Crypto is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2, or (at your option)
// any later version.
//
// GNU Crypto is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; see the file COPYING.  If not, write to the
//
//    Free Software Foundation Inc.,
//    59 Temple Place - Suite 330,
//    Boston, MA 02111-1307
//    USA
//
// Linking this library statically or dynamically with other modules is
// making a combined work based on this library.  Thus, the terms and
// conditions of the GNU General Public License cover the whole
// combination.
//
// As a special exception, the copyright holders of this library give
// you permission to link this library with independent modules to
// produce an executable, regardless of the license terms of these
// independent modules, and to copy and distribute the resulting
// executable under terms of your choice, provided that you also meet,
// for each linked independent module, the terms and conditions of the
// license of that module.  An independent module is a module which is
// not derived from or based on this library.  If you modify this
// library, you may extend this exception to your version of the
// library, but you are not obligated to do so.  If you do not wish to
// do so, delete this exception statement from your version.
// ----------------------------------------------------------------------------

import gnu.crypto.Registry;
import gnu.crypto.sig.rsa.EME_PKCS1_V1_5;
import gnu.crypto.util.PRNG;
import gnu.crypto.util.Util;

import java.io.PrintWriter;

/**
 * <p>A padding algorithm implementation of the EME-PKCS1-V1.5 encoding/decoding
 * algorithm as described in section 7.2 of RFC-3447. This is effectively an
 * <i>Adapter</i> over an instance of {@link EME_PKCS1_V1_5} initialised with
 * the RSA public shared modulus length (in bytes).</p>
 *
 * <p>References:</p>
 * <ol>
 *    <li><a href="http://www.ietf.org/rfc/rfc3447.txt">Public-Key Cryptography
 *    Standards (PKCS) #1:</a><br>
 *    RSA Cryptography Specifications Version 2.1.<br>
 *    Jakob Jonsson and Burt Kaliski.</li>
 * </ol>
 *
 * @version $Revision: 1.1 $
 * @see EME_PKCS1_V1_5
 */
public class PKCS1_V1_5 extends BasePad {

   // Debugging methods and variables
   // -------------------------------------------------------------------------

   private static final String NAME = Registry.EME_PKCS1_V1_5_PAD;
   private static final boolean DEBUG = false;
   private static final int debuglevel = 9;
   private static final PrintWriter err = new PrintWriter(System.out, true);
   private static void debug(final String s) {
      err.println(">>> "+NAME+": "+s);
   }

   // Constants and variables
   // -------------------------------------------------------------------------

   private EME_PKCS1_V1_5 codec;

   // Constructor(s)
   // -------------------------------------------------------------------------

   /**
    * <p>Trivial package-private constructor for use by the <i>Factory</i> class.
    * </p>
    *
    * @see gnu.crypto.pad.PadFactory
    */
   PKCS1_V1_5() {
      super(Registry.EME_PKCS1_V1_5_PAD);
   }

   // Class methods
   // -------------------------------------------------------------------------

   // Implementation of abstract methods in BasePad
   // -------------------------------------------------------------------------

   public void setup() {
      codec = EME_PKCS1_V1_5.getInstance(blockSize);
   }

   public byte[] pad(final byte[] in, final int offset, final int length) {
      final byte[] M = new byte[length];
      System.arraycopy(in, offset, M, 0, length);
      final byte[] EM = codec.encode(M);
      final byte[] result = new byte[blockSize - length];
      System.arraycopy(EM, 0, result, 0, result.length);
      if (DEBUG && debuglevel > 8) {
         debug("padding: 0x"+Util.toString(result));
      }
      return result;
   }

   public int unpad(final byte[] in, final int offset, final int length)
   throws WrongPaddingException {
      final byte[] EM = new byte[length];
      System.arraycopy(in, offset, EM, 0, length);
      final int result = length - codec.decode(EM).length;
      if (DEBUG && debuglevel > 8) {
         debug("padding length: "+String.valueOf(result));
      }
      return result;
   }

   // overloaded methods ------------------------------------------------------

   public boolean selfTest() {
      final int[] mLen = new int[] { 16, 20, 32, 48, 64 };
      final byte[] M = new byte[mLen[mLen.length - 1]];
      PRNG.nextBytes(M);
      final byte[] EM = new byte[1024];
      byte[] p;
      int bs, i, j;
      for (bs = 256; bs < 1025; bs += 256) {
         init(bs);
         for (i = 0; i < mLen.length; i++) {
            j = mLen[i];
            p = pad(M, 0, j);
            if (j + p.length != blockSize) {
               new RuntimeException(name()).printStackTrace(System.err);
               return false;
            }

            System.arraycopy(p, 0, EM, 0,        p.length);
            System.arraycopy(M, 0, EM, p.length, j);
            try {
               if (p.length != unpad(EM, 0, blockSize)) {
                  new RuntimeException(name()).printStackTrace(System.err);
                  return false;
               }
            } catch (WrongPaddingException x) {
               x.printStackTrace(System.err);
               return false;
            }
         }
         reset();
      }

      return true;
   }
}
